/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package math.geo.soap;

import java.io.IOException;
import java.util.LinkedList;
import javax.annotation.Resource;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.servlet.ServletContext;
import javax.xml.bind.JAXBException;
import javax.xml.ws.WebServiceContext;
import javax.xml.ws.handler.MessageContext;
import math.geo.*;

/**
 *
 * @author George
 */
@WebService(serviceName = "GeometryService")
public class GeometryService {
    
    @Resource
    private WebServiceContext context;
    
    private Geometry getGeo() throws JAXBException, IOException, Exception {
         ServletContext application = (ServletContext)context.getMessageContext().get(MessageContext.SERVLET_CONTEXT);
        // The web server can handle requests from different clients in parallel.
        // These are called "threads".
        //
        // We do NOT want other threads to manipulate the application object at the same
        // time that we are manipulating it, otherwise bad things could happen.
        //
        // The "synchronized" keyword is used to lock the application object while
        // we're manpulating it.
        synchronized (application) {
            Geometry geo = (Geometry) application.getAttribute("geometry");
            if (geo == null) {
                geo = new Geometry();
                
            }
            return geo;
        }
    }
    /**
     * This is a sample web service operation
     * @param txt
     * @return 
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    /**
     *
     * @param a
     * @param b
     * @return
     * @throws java.io.IOException
     */
    @WebMethod
    public double distance(Point a, Point b) throws IOException, Exception{
        return getGeo().distance(a, b);
    }
    
    @WebMethod
    public Geometry geo() throws IOException, Exception{
        return getGeo();
    }
    
    /**
     *
     * @param a
     * @param b
     * @return
     * @throws java.io.IOException
     */
    @WebMethod
    public Point median(Point a, Point b) throws IOException, Exception{
        return getGeo().median(a, b);
    }
    
    /**
     *
     * @return
     * @throws java.io.IOException
     */
    @WebMethod
    public LinkedList<Point> points() throws IOException, Exception{
        return getGeo().getPoints();
    }
}
