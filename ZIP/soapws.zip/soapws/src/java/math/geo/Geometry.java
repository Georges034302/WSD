/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package math.geo;

import java.util.LinkedList;
import javax.xml.bind.annotation.*;
import javax.xml.bind.annotation.XmlAccessorType;

/**
 *
 * @author George
 */
@XmlRootElement(name = "geometry")
@XmlAccessorType(XmlAccessType.FIELD)
public class Geometry {
    
    @XmlElement(name = "point")
    private LinkedList<Point> points;
    
    public Geometry(){
        this.points = new LinkedList();
        points.add(new Point(1,1));
        points.add(new Point(1,4));
        points.add(new Point(4,1));
        points.add(new Point(4,4));
    }
    
    public double distance(Point a, Point b){
        return Math.sqrt(Math.pow((a.getX()-b.getX()), 2)+Math.pow(a.getY()-b.getY(), 2));
    }
    
    public Point median(Point a, Point b){
        return new Point((a.getX()+b.getX())/2, (a.getY()+b.getY())/2);
    }
    public LinkedList<Point> getPoints(){
        return points;
    }    
    
}
