/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd;

import javax.xml.bind.annotation.*;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Circle {
    private double radius;

    public Circle() {
        super();
    }

    public Circle(double radius) {
        super();
        this.radius = radius;
    }

    @XmlElement
    public double getRadius() {
        return radius;
    }
    @XmlElement
    public double  getArea(){        
        return Math.PI*Math.pow(radius, 2);
    }

    @XmlElement
    public double getPeremiter(){
        return 2*Math.PI*radius;
    }
    public void setRadius(double radius) {
        this.radius = radius;
    }
    
}
