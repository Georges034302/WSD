package uts.wsd;
 
import java.util.*;
import java.io.Serializable;
import javax.xml.bind.annotation.*;

@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "users")
public class Users implements Serializable {
	// The list of user elements does NOT have an extra wrapper element.
	// See the comment in the XML file, and compare to the bookshop example.
	@XmlElement(name = "user")
    private ArrayList<User> list = new ArrayList<User>();
 
    public ArrayList<User> getList() {
        return list;
    }
    public void addUser(User user) {
        list.add(user);
    }
    public void removeUser(User user) {
        list.remove(user);
    }
    public User login(String email, String password) {
        // For each user in the list...
        for (User user : list) {
            if (user.getEmail().equals(email) && user.getPassword().equals(password))
                return user; // Login correct. Return the user.
        }
        return null; // Login incorrect. Return a null user.
    }
    public User getUser(String email) {
        for (User user : list) {
            if (user.getEmail().equals(email))
                return user;
        }
        return null;
    }
    public void deleteUser(String email){
    	User user = getUser(email);
    	if(user != null)
    		removeUser(user);
    	else
    		System.out.println("User Doesn't exist!");
    }
}
