/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd.rest;

import javax.ws.rs.core.Context;
import javax.ws.rs.core.UriInfo;
import javax.ws.rs.Consumes;
import javax.ws.rs.Produces;
import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.PUT;
import javax.ws.rs.QueryParam;
import javax.ws.rs.core.MediaType;
import uts.wsd.Circle;
import uts.wsd.Rectangle;

/**
 * REST Web Service
 *
 * @author Georges
 */
@Path("geometry")
public class GeometryResource {

   @Context
    private UriInfo context;

    /**
     * Creates a new instance of GeometryResource
     */
    public GeometryResource() {
    }

     @Path("hello")
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
        return "Hello World";
    }

    @Path("rectangle")
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public Rectangle rectangle(@QueryParam("width") double width, @QueryParam("height") double height) {
        return new Rectangle(width,height);
    }
    @Path("circle")
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public Circle circle(@QueryParam("radius") double radius) {
        return new Circle(radius);
    }
}
