package uts.wsd.rest.client;
import com.sun.jersey.api.client.Client;
import com.sun.jersey.api.client.ClientResponse;
 
public class GeoClient {
 public static void main(String[] args) {
  Client client = Client.create();
  ClientResponse response = client
     .resource("http://freegeoip.net/xml/138.25.6.1")
     .accept("application/xml")
     .get(ClientResponse.class);
 
  int status = response.getStatus();
  if (status == 200) {
   Location location = response.getEntity(Location.class);
   System.out.println("That IP address is in " + location.getCountryName());
  }
  else {
   System.out.println("Web service returned with status " + status);
  }
 }
}