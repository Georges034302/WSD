/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd.soap.client;

import java.net.MalformedURLException;
import java.net.URL;
import javax.xml.namespace.QName;
import javax.xml.ws.Service;
import javax.xml.ws.WebEndpoint;
import javax.xml.ws.WebServiceClient;
import javax.xml.ws.WebServiceException;
import javax.xml.ws.WebServiceFeature;

/**
 *
 * @author Georges
 */
public class CalculatorClient {

    public static void main(String[] args) {
        //Calculator_Service locator = new Calculator_Service();
        //Calculator calculator = locator.getCalculatorPort();

//  System.out.println("Add "+calculator.add(2, 3));
        /**
         * Insert your code here *
         */
    }

    public int calculate(int a, char op, int b) {
        Calculator_Service locator = new Calculator_Service();
        Calculator calculator = locator.getCalculatorPort();
        int result = 0;
        switch (op) {
            case '-':
               result = calculator.sub(a, b);
                break;
            case '+':
                result = calculator.add(a, b);
                break;
            case '*':
                result = calculator.mul(a, b);
                break;
            case '/':
                result = calculator.div(a, b);
                break;
        }
        
        return result;
    }

}
