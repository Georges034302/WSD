package uts.wsd.rest;

import javax.ws.rs.*;
import javax.ws.rs.core.*;
import uts.wsd.*;

@Path("/mathApp")
public class Calculator {
    @Context
    private UriInfo context;
    
    public Calculator() {}
    
    @Path("formula")
    @GET
    @Produces(MediaType.TEXT_XML)
    public Formula formula(@QueryParam("n") int n){
        return new Formula(n);
    }
}
