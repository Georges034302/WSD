package demo.ws.rest;

import demo.ws.bean.Formula;
import javax.ws.rs.*;
import javax.ws.rs.core.*;

@Path("/mathApp")
public class MathREST {
    @Context
    private UriInfo context;
    
    public MathREST() {}
    
    @Path("formula")
    @GET
    @Produces(MediaType.TEXT_XML)
    public Formula formula(@QueryParam("n") int n){
        return new Formula(n);
    }
}
