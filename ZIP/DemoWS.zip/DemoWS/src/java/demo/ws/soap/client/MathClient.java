
package demo.ws.soap.client;

public class MathClient {
    
    public MathClient(){}
    Math_Service locator = new Math_Service();
    Math ms = locator.getMathPort();
    public static void main(String[] args){
    Math_Service locator = new Math_Service();
    Math ms = locator.getMathPort();
    
    System.out.println("Factorial 5 = "+ms.factorial(5));
    }
    
    public int factorial(int n){        
        return ms.factorial(n);
    }   

    public double squareroot(int n){
        return ms.squareroot(n);
    }
    
    public double logarithm(int n){
        return ms.logarithm(n);
    }
    
    public double exponent(int n){
        return ms.exponent(n);
    }
}
