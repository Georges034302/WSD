/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package demo.ws.soap;

import demo.ws.bean.Formula;
import javax.jws.*;
/**
 *
 * @author george
 */
@WebService(serviceName = "Math")
public class Math {

    @WebMethod(operationName = "factorial")
    public int getFactorial(@WebParam(name = "n") int n) {
        return new Formula(n).getFactorial();
    }
    
    @WebMethod(operationName="logarithm")
    public double getLogarithm(@WebParam(name = "n") int n){
        return new Formula(n).getLogarithm();
    }
    @WebMethod(operationName="Squareroot")
    public double getSquareroot(@WebParam(name = "n") int n){
        return new Formula(n).getSquareroot();
    }
    @WebMethod(operationName="Exponent")
    public double getExponent(@WebParam(name = "n") int n){
        return new Formula(n).getExponent();
    }
}
