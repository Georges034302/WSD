package controller;

import javafx.collections.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.text.*;
import javafx.scene.control.*;
import javafx.stage.*;
import javafx.beans.property.*;
import java.io.*;
import au.edu.uts.ap.javafx.*;
import javafx.scene.input.MouseEvent;
import model.*;

public class StadiumController extends Controller<Stadium>{
    //define a listview of groups as FXML element
    
    //define a public constant getStadium() that returns a stadium object from protected model of parent Controller
    
    //define a private getGroup() that returns a selected group from the listview
    
    //define private FXML method initialize
    
    //define private FXML method handleOpen that handles button action event 
    //Once 'Open' button is clicked, ViewLoader showstage method will show a selected group menu
    //on stage
    
    //Another way is to implment a method that handles mouse click events and generates
    //group menu for a selected group on view
    
    
    
       /**
     *
     * @param event
     * @throws Exception
     */
    @FXML private void handleMouseClicked(MouseEvent event) throws Exception {
        ViewLoader.showStage(model, "/view/group.fxml", "Stadium", new Stage());
    }
}
