package uts.wsd.soap;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.xml.ws.Endpoint;
  
@WebService
public class Calculator {
 
 @WebMethod
 public int add(int a, int b) {
  return a+b;
 }
}