/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package lab8;
import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;
import javafx.event.*;
/**
 *
 * @author George
 */
public class Calculator extends Application {
    public static void main(String[] args) { launch(args); }

    private Label firstNumberLbl;
    private TextField firstNumberTf;
    private Label secondNumberLbl;
    private TextField secondNumberTf;
    private Label resultLbl;
    private TextField resultTf;
    private Button addBtn;
    private Button subBtn;
    private Button mulBtn;
    private Button divBtn;

    private void createLeafNodes(){
        firstNumberLbl = new Label("First number");
        firstNumberTf = new TextField();
        secondNumberLbl = new Label("Second number");
        secondNumberTf = new TextField();
        resultLbl = new Label("Result");
        resultTf = new TextField();
        addBtn = new Button("+");
        subBtn = new Button("-");
        mulBtn = new Button("*");
        divBtn = new Button("/");
    }
    private VBox createBranchNode(){
        VBox vbox = new VBox(10,
                            firstNumberLbl,firstNumberTf,
                            secondNumberLbl,secondNumberTf,
                            resultLbl,resultTf,
                            addBtn,subBtn,mulBtn,divBtn);
        vbox.setAlignment(Pos.CENTER);
        return vbox;
    }
    private void setEventHandlers(){
        addBtn.setOnAction(event -> setResult(getFirst()+getSecond()));
        subBtn.setOnAction(event -> setResult(getFirst()-getSecond()));
        mulBtn.setOnAction(event -> setResult(getFirst()*getSecond()));
        divBtn.setOnAction(event -> setResult((double)getFirst()/getSecond()));
    }

    public int getFirst() {
        return Integer.parseInt(firstNumberTf.getText());
    }

    public void setFirstNumberTf(int first) {
        this.firstNumberTf.setText(""+first);
    }

    public int getSecond() {
        return Integer.parseInt(secondNumberTf.getText());
    }

    public void setSecondNumberTf(int second) {
        this.secondNumberTf.setText(""+second);
    }

    public int getResultTf() {
        return Integer.parseInt(resultTf.getText());
    }

    public void setResult(double result) {
        this.resultTf.setText(""+result);
    }
    private void setScene(Stage stage,VBox vbox){
        stage.setScene(new Scene(vbox));
        stage.setTitle("Calculator");
        stage.show();
    }
    @Override
    public void start(Stage stage) throws Exception {
        createLeafNodes();
        VBox vbox = createBranchNode();
        setEventHandlers();        
        setScene(stage,vbox);
    }
}