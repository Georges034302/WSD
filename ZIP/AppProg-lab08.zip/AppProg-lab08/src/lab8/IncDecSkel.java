package lab8;

import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;

/**
 * This application allows the user to increment and decrement a value.
 */
public class IncDecSkel extends Application {
    public static void main(String[] args) { launch(args); }

    private Label valueLbl;
    private TextField valueTf;
    private Button decBtn;
    private Button incBtn;

    @Override
    public void start(Stage stage) {
        // Create the leaves
       
        // Add the leaves to a branch
        
        // Set the event handlers
        
        // Set the scene, show the stage
    }

    // TextField getter/setter
}
