package lab8;

import javafx.application.Application;
import javafx.event.EventHandler;
import javafx.event.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

public class IncDecAll extends Application {
    
    public static void main(String[] args){ launch(args);}    

    private Label valueLbl;
    private TextField inputField; 
    private Button addBtn;
    private Button subBtn;
    private Button resetBtn;
        
    @Override
    public void start(Stage stage) throws Exception {
       valueLbl = new Label("Value");
       inputField = new TextField("0");
       addBtn = new Button("+1");
       subBtn = new Button("-1");
       resetBtn = new Button("C");
       
       HBox box = new HBox(10,valueLbl,inputField,addBtn,subBtn,resetBtn);
       
        addBtn.setOnAction(new EventHandler<ActionEvent>() { 
            @Override public void handle(ActionEvent event) {
                setValue(getValue()+1);
            }
        });
        
        subBtn.setOnAction(event->{setValue(getValue()-1);});
        resetBtn.setOnAction(new ButtonHandler());
        
        stage.setScene(new Scene(box));
        stage.setTitle("Inc-Dec");
        stage.show();
        
    }
    
    public void setValue(int value){
        inputField.setText(""+value);
    }
    public int getValue(){
        return Integer.parseInt(inputField.getText());
    }
    
    private class ButtonHandler implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent event) {
            inputField.setText("0");
        }        
    }
}
