package lab8;

import javafx.application.*;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;
import javafx.scene.paint.Color;

/**
 * This application allows the user to increment and decrement a value.
 */
public class IncDecLamda extends Application {
    public static void main(String[] args) { launch(args); }

    private Label valueLbl;
    private TextField valueTf;
    private Button decBtn;
    private Button incBtn;

    private int getValue(){
        return Integer.parseInt(valueTf.getText());
    }
    private void setValue(int value){
        valueTf.setText(""+value);
    }
    private Button button(String label){  
        Button button = new Button(label);
        button.setStyle("-fx-font-weight: bold;"
                        + "-fx-font-family: \"Courier New\";"
                        + "-fx-font: 20px \"Serif\";"
                        + "-fx-text-fill: white;"
                        + "-fx-background-color: #009933;"); 
        return button;
    }
    
    private Label label(String name){
        Label label = new Label(name);
        label.setFont(Font.font("Ariel", FontWeight.BOLD, FontPosture.REGULAR, 14));
        label.setTextFill(Color.web("#0000ff"));
        return label;
    }
    
    private TextField field(){
        TextField field  = new TextField("0");        
        field.setStyle("-fx-font-weight: bold;"
                        + "-fx-font-family: \"Courier New\";"
                        + "-fx-font: 20px \"Serif\";"
                        + "-fx-text-fill: red;"
                        + "-fx-background-color: #ffffcc;");
        
        return field;
    }
    private HBox hbox(){
        HBox hBox = new HBox(10,valueLbl, valueTf, decBtn, incBtn);
        hBox.setAlignment(Pos.CENTER);
        hBox.setPadding(new Insets(15, 12, 15, 12));
        hBox.setStyle("-fx-background-color: #ccccff;");
        return hBox;
    }
    private void buildLeaves(){
         // Create the leaves
        valueLbl = label("Value");
        valueTf = field();        
        decBtn = button("-1");
        incBtn = button("+1");
    }
    private GridPane gridPane(){
        GridPane grid = new GridPane();
        grid.setHgap(10);
        grid.setVgap(10);
        grid.setStyle("-fx-background-color: #ccccff;");
        grid.setPadding(new Insets(15, 12, 15, 12));
        grid.add(valueLbl, 0, 0);
        grid.add(valueTf, 1, 0);
        grid.add(decBtn, 2, 0);
        grid.add(incBtn, 3, 0);
        return grid;
    }
    
    private TilePane tilePane(){
        TilePane tile = new TilePane();
        tile.setPadding(new Insets(5, 5, 5, 5));
        tile.setVgap(1);
        tile.setHgap(5);
        tile.setPrefColumns(4);
        tile.setStyle("-fx-background-color: #ccccff;");
        tile.getChildren().addAll(valueLbl,valueTf,incBtn,decBtn);
        return tile;
    }
    @Override
    public void start(Stage stage) throws Exception {
        buildLeaves();        
        // Set the event handlers
        incBtn.setOnAction(event -> setValue(getValue()+1));
        decBtn.setOnAction(event -> setValue(getValue()-1));
        // Set the scene, show the stage
        stage.setScene(new Scene(gridPane()));
        stage.setTitle("Increment-Decrement");
        stage.show();
    }

    // TextField getter/setter
}
