package practice;
import javafx.application.*;
import javafx.event.*;
import javafx.event.EventHandler;
import javafx.stage.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.scene.text.*;
import javafx.geometry.*;
/**
 * This application allows the user to increment and decrement a value.
 */
public class IncDecPractice extends Application {
    public static void main(String[] args) { launch(args); }

    private Label valueLbl;
    private TextField valueTf;
    private Button decBtn;
    private Button incBtn;

    private int getValue(){
        return Integer.parseInt(valueTf.getText());
    }
    private void setValue(int value){
        valueTf.setText(""+value);
    }
    @Override
    public void start(Stage stage) {
        // Create the leaves
        valueLbl = new Label("Value");
        valueTf = new TextField("0");
        decBtn = new Button("-1");
        incBtn = new Button("+1");
        // Add the leaves to a branch
        HBox hbox = new HBox(10,valueLbl,valueTf,decBtn,incBtn);
        hbox.setPadding(new Insets(10,10,10,10));
        // Set the event handlers
        decBtn.setOnAction(new IncDecHandler());
        
        incBtn.setOnAction(new IncDecHandler());
        // Set the scene, show the stage
        stage.setScene(new Scene(hbox));
        stage.setTitle("Practice");
        stage.show();
    }

    private class IncDecHandler implements EventHandler<ActionEvent>
    {
        @Override
        public void handle(ActionEvent e){
            if(e.getSource()==decBtn)
                setValue(getValue()-1);
            else if(e.getSource()==incBtn)
                setValue(getValue()+1);
        }
    }
}
