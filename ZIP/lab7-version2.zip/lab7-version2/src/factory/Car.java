package factory;

public abstract class Car{

    protected String type;
    protected int pos;
    protected int distance;
    
    protected Car(String type, int start){
        this.type = type;
        this.pos = start;
    }   
    public void start() {
        System.out.println(type +" is starting at position: "+pos);
    }
    public void stop() {
        System.out.println(type +" is stopping at position: "+pos);
    } 
    public void move(){
        pos += distance;
        System.out.println(type +" has moved to position: "+pos);
    }
    protected abstract void setdistance(int distance);   
}
