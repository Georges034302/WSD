package factory.cars;

import factory.Car;

public class Audi extends Car{
    public Audi(){
        super("Audi",0);
    }

    @Override
    protected void setdistance(int distance) {
        super.distance += distance;
    }   
      
    @Override
    public void move(){
        setdistance(10);
        super.move();
    }
}
