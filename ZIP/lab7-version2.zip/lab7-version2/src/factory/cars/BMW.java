package factory.cars;

import factory.Car;

public class BMW extends Car{
    
    public BMW(){
        super("BMW",0);
    }    

    @Override
    protected void setdistance(int distance) {
         super.distance += distance;
    }   
    
    @Override
    public void move(){
        setdistance(20);
        super.move();
    }
}
