/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd;

import javax.xml.bind.annotation.*;

/**
 *
 * @author George
 */
@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Circle {

    private double radius;

    public Circle() {
        super();
    }

    public Circle(double radius) {
        super();
        this.radius = radius;
    }

    @XmlElement
    public double getRadius() {
        return radius;
    }
    
    @XmlElement
    public double getDiameter(){
        return 2*radius;
    }
    
    @XmlElement
    public double getPeremeter(){
        return 2*radius*Math.PI;
    }
    
    @XmlElement
    public double getArea(){
        return Math.PI*Math.pow(radius, 2);
    }
}
