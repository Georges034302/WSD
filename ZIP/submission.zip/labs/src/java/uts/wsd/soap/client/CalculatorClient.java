/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd.soap.client;

/**
 *
 * @author George
 */
public class CalculatorClient {
 public static void main(String[] args) {
 Calculator_Service locator = new Calculator_Service();
 Calculator calculator = locator.getCalculatorPort();
 
 System.out.println("a+b = "+calculator.add(3, 4));
 }
}