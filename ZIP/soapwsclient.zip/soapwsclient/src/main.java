
import java.util.LinkedList;
import java.util.List;
import soap.client.Exception_Exception;
import soap.client.GeometryService;
import soap.client.GeometryService_Service;
import soap.client.IOException_Exception;
import soap.client.Point;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author George
 */
public class main {

    /**
     * @param args the command line arguments
     * @throws soap.client.IOException_Exception
     * @throws soap.client.Exception_Exception
     */
    public static void main(String[] args) throws IOException_Exception, Exception_Exception {
        GeometryService_Service gs = new GeometryService_Service() ;
        GeometryService geo = gs.getGeometryServicePort();
        
        List<Point> points = geo.points();
        
        System.out.println("distance = "+ geo.distance(points.get(0), points.get(3)));
    }
    
}
