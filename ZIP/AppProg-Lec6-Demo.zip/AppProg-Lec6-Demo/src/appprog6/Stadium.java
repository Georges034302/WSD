/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appprog6;

import java.util.LinkedList;

/**
 *
 * @author George
 */
public class Stadium {
    private LinkedList<Group> groups = new LinkedList();
    private double income;
    
    public static void main(String[] args){
        (new Stadium()).use();
    }
    public Stadium(){
        this.income = 0.0;
        loadGroups();
    }
    private void loadGroups(){
        groups.add(new Group("front",300,400));
        groups.add(new Group("middle", 1500, 100));
        groups.add(new Group("back",200,60));
    }
    private char readChoice(){
        System.out.print("Choice(s/v/i/x): ");
        return In.nextChar();
    }
    private void use(){
        char c;
        while((c=readChoice())!='x'){
            switch(c){
                case 's': sell(); break;
                case 'v': viewGroups(); break;
                case 'i': viewIncome(); break;
                default: help(); break;
            }
        }
    }    
    
    private String readType(){
        System.out.print("Group: ");
        return In.nextLine();
    }
    private int readNumber(String type){
        System.out.print("Number of "+type+" seats: ");
        return In.nextInt();
    }
    private Group group(String type){
        for(Group group:groups)
        {
            if(group.match(type))
                return group;
        }
        return null;
    }
    
    private void sell(){
        String type = readType();
        Group group = group(type);
        if(group!= null){
            int n = readNumber(type);
            if(group.has(n)){
                income += group.sell(n);
            }else{
                System.out.println("Group "+type+" level is less than "+n);
            }
        }else{
            System.out.println("Group "+type+" does not exist!");
        }        
    }
    private void viewGroups(){
        for(Group group:groups)
            System.out.println(group);
    }
    private void viewIncome(){
        System.out.println("The income is: $"+In.formatted(income));
    }
    private void help(){
        System.out.println("Choose a command: "
                + "\n 's' to sell:"
                + "\n 'v' to view groups:"
                + "\n 'i' to view income:"
                + "\n 'x' to exit:");
    }
}
