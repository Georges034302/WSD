/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package appprog6;

/**
 *
 * @author George
 */
public class Group {
    private String type;
    private int level;
    private double price;
    
    public Group(String type, int level, double price)
    {
        this.type = type;
        this.level = level;
        this.price = price;
    }
    
    public boolean match(String type){
        return this.type.toLowerCase().endsWith(type);
    }
    public boolean has(int number){
        return level >=number;
    }
    public double sell(int number){
        level -= number;
        return number*price;
    }
    @Override
    public String toString()
    {
        return level+" "+type+" seats @ $"+In.formatted(price);
    }
}
