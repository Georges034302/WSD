/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd.test;

import java.net.*;
import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;
import static org.junit.Assert.*;
import org.junit.runner.JUnitCore;
import org.junit.runner.Result;
import org.junit.runner.RunWith; 
//import cucumber.junit.Cucumber; 
import cucumber.api.junit.Cucumber;


import uts.wsd.controller.MongoDBConnector;

/**
 *
 * @author George
 */


public class MavenJUnitTest {
    
    public MavenJUnitTest() {
    }
    

    
    @Test
    public void testMongoDBConnect() throws UnknownHostException{
        Assert.assertNotNull(new MongoDBConnector());
        Result results = JUnitCore.runClasses(MavenJUnitTest.class);
        System.out.println("\n Connection to MongoDB status = "+results.wasSuccessful());
    }

    @BeforeClass
    public static void setUpClass() {
        System.out.print("Starting test");
    }
    
    
    @AfterClass
    public static void tearDownClass() {
        System.out.print("Test Finished");
    }
    
    @Before
    public void setUp() {
    }
    
    @After
    public void tearDown() {
    }  
    
}
