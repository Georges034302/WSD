/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd.test;

/**
 *
 * @author George
 */
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;
import cucumber.api.PendingException;

import org.openqa.selenium.chrome.ChromeDriver;

public class CucumberTest {

    WebDriver driver = null;

    @Given("^I have open the browser$")
    public void openBrowser() {
        driver = new ChromeDriver();
    }

    @When("^I open Maven-App website$")
    public void goToMyApp() {
        driver.navigate().to("https://maven-app-heroku.herokuapp.com/");
    }

    @Then("^Register Link should exits$")
    public void loginButton() {
        if (driver.findElement(By.id("registerID")).isEnabled()) {
            System.out.println("Test 1 Pass");
        } else {
            System.out.println("Test 1 Fail");
        }
        driver.close();
    }
}
