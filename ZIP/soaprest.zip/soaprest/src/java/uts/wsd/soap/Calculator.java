/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd.soap;

import javax.jws.*;
import java.util.*;

/**
 *
 * @author Georges
 */
@WebService
public class Calculator {

    @WebMethod(operationName = "add")
    public int add(int a, int b) {
        return a+b;
    }

    /**
     * Web service operation
     */
    @WebMethod(operationName = "sub")
    public int sub(@WebParam(name = "a") int a, @WebParam(name = "b") int b) {
        
        return a-b;
    }

}
