package uts.wsd;

import javax.xml.bind.annotation.*;

@XmlRootElement
@XmlAccessorType(XmlAccessType.PROPERTY)
public class Location {

    private String ip;
    private String countryCode;
    private String countryName;    
    private String city;
    private String zipCode;
    
    public Location() {
        super();
    }

    public Location(String ip, String countryCode, String countryName, String city, String zipCode) {
        super();
        this.ip = ip;
        this.countryCode = countryCode;
        this.countryName = countryName;        
        this.city = city;
        this.zipCode = zipCode;     
    }

    @XmlElement
    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    @XmlElement
    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    @XmlElement
    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }
    @XmlElement
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    @XmlElement
    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }
}