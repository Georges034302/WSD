/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd.rest.client;

import javax.ws.rs.ClientErrorException;
import javax.ws.rs.client.Client;
import javax.ws.rs.client.WebTarget;
import javax.ws.rs.core.*;
import java.util.*;

/**
 * Jersey REST client generated for REST resource:GeoService [geo]<br>
 * USAGE:
 * <pre>
 *        GeoClient client = new GeoClient();
 *        Object response = client.XXX(...);
 *        // do whatever with response
 *        client.close();
 * </pre>
 *
 * @author Georges
 */
public class GeoClient {

    private WebTarget webTarget;
    private Client client;
    private Response response;
    private Location location;
    private static final String BASE_URI = "http://localhost:8080/testrest/rest";
    private static Scanner in = new Scanner(System.in);
    
    public static void main(String[] args){
        
        
        System.out.print("Check IP: ");        
        String link =  "http://freegeoip.net/xml/"+in.nextLine();
        //String link = "http://freegeoip.net/xml/138.25.6.1";
        GeoClient geo = new GeoClient(link);
        geo.location();
        
    }
    public GeoClient(String link) {
        
        client = javax.ws.rs.client.ClientBuilder.newClient();
        webTarget = client.target(BASE_URI).path("geo");
        response = client.target(link)
                         .request("application/xml")
                         .get();
        location = response.readEntity(Location.class); 
    }

    public void location() throws ClientErrorException {
        //WebTarget resource = webTarget;
        if (location.getCountryName() != null) {
            System.out.println("Region : "+location.getRegionName());
        }
        if (location.getCity() != null) {
            System.out.println("City : "+location.getCity());
        }
        if (location.getAreaCode() != null) {
            System.out.println("Area Code : "+location.getAreaCode());
        }
        if (location.getCountryCode() != null) {
            System.out.println("Country : "+location.getCountryCode());
        }
        if (location.getIp() != null) {
            System.out.println("IP : "+location.getIp());
        }
    }

    public void close() {
        client.close();
    }
    
}
