/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd.rest;

import javax.ws.rs.*;
import javax.ws.rs.core.*;
import uts.wsd.*;

/**
 * REST Web Service
 *
 * @author Georges
 */
@Path("geometry")
public class GeometryService {

    @Context
    private UriInfo Context;

    /**
     * Creates a new instance of GeometryService
     */
    public GeometryService() {
    }

    @Path("hello")
    @GET
    @Produces(MediaType.TEXT_PLAIN)
    public String hello() {
        return "Hello World";
    }
    @Path("rectangle")
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public Rectangle rectangle(@QueryParam("width") double width, @QueryParam("height") double height) {
        return new Rectangle(width,height);
    }
    @Path("circle")
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public Circle rectangle(@QueryParam("radius") double radius) {
        return new Circle(radius);
    }
    /**
     * Retrieves representation of an instance of uts.wsd.rest.GeometryService
     * @return an instance of java.lang.String
     */
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public String getXml() {
        //TODO return proper representation object
        throw new UnsupportedOperationException();
    }

    /**
     * PUT method for updating or creating an instance of GeometryService
     * @param content representation for the resource
     */
    @PUT
    @Consumes(MediaType.APPLICATION_XML)
    public void putXml(String content) {
    }
}
