package uts.wsd.rest.client;
import javax.xml.bind.annotation.*;
 
@XmlAccessorType(XmlAccessType.FIELD)
@XmlRootElement(name = "Response")
public class Location {
 @XmlElement(name = "Ip")
 private String ip;
 @XmlElement(name = "CountryCode")
 private String countryCode;
 @XmlElement(name = "CountryName")
 private String countryName;
 @XmlElement(name = "RegionCode")
 private String regionCode;
 @XmlElement(name = "RegionName")
 private String regionName;
 @XmlElement(name = "City")
 private String city;
 @XmlElement(name = "ZipCode")
 private String zipCode;
 @XmlElement(name = "Latitude")
 private double latitude;
 @XmlElement(name = "Longitude")
 private double longitude;
 @XmlElement(name = "MetroCode")
 private String metroCode;
 @XmlElement(name = "AreaCode")
 private String areaCode;

    public Location() {
    }

    public Location(String ip, String countryCode, String countryName, String regionCode, String regionName, String city, String zipCode, double latitude, double longitude, String metroCode, String areaCode) {
        this.ip = ip;
        this.countryCode = countryCode;
        this.countryName = countryName;
        this.regionCode = regionCode;
        this.regionName = regionName;
        this.city = city;
        this.zipCode = zipCode;
        this.latitude = latitude;
        this.longitude = longitude;
        this.metroCode = metroCode;
        this.areaCode = areaCode;
    }

    public String getIp() {
        return ip;
    }

    public void setIp(String ip) {
        this.ip = ip;
    }

    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }

    public String getCountryName() {
        return countryName;
    }

    public void setCountryName(String countryName) {
        this.countryName = countryName;
    }

    public String getRegionCode() {
        return regionCode;
    }

    public void setRegionCode(String regionCode) {
        this.regionCode = regionCode;
    }

    public String getRegionName() {
        return regionName;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZipCode() {
        return zipCode;
    }

    public void setZipCode(String zipCode) {
        this.zipCode = zipCode;
    }

    public double getLatitude() {
        return latitude;
    }

    public void setLatitude(double latitude) {
        this.latitude = latitude;
    }

    public double getLongitude() {
        return longitude;
    }

    public void setLongitude(double longitude) {
        this.longitude = longitude;
    }

    public String getMetroCode() {
        return metroCode;
    }

    public void setMetroCode(String metroCode) {
        this.metroCode = metroCode;
    }

    public String getAreaCode() {
        return areaCode;
    }

    public void setAreaCode(String areaCode) {
        this.areaCode = areaCode;
    }
    
 
}