package uts.wsd.rest;

import java.io.IOException;

import uts.wsd.*;

import javax.servlet.ServletContext;
import javax.ws.rs.*;
import javax.ws.rs.core.*;
import javax.xml.bind.JAXBException;

@Path("/diaryApp")
public class DiaryService {
	@Context
	private ServletContext application;
	
	private DiaryApplication getDiaryApp() throws JAXBException, IOException, Exception {
		synchronized (application) {
			DiaryApplication diaryApp = (DiaryApplication)application.getAttribute("diaryApp");
			if (diaryApp == null) {
				diaryApp = new DiaryApplication();
				diaryApp.setFilePath(application.getRealPath("WEB-INF/users.xml"));
				application.setAttribute("diaryApp", diaryApp);
			}
			return diaryApp;
		}
	}
	
	@GET
	@Path("users")
	@Produces(MediaType.APPLICATION_XML)
	public Users getUsers() throws JAXBException, IOException, Exception {
		return getDiaryApp().getUsers();
	}
	
	@GET
	@Path("users/{email}")
	@Produces(MediaType.APPLICATION_XML)
	public User getUser(@PathParam("email") String email) throws JAXBException, IOException, Exception {
		return getDiaryApp().getUsers().getUser(email);
	}
	
	@POST
	@Path("users")
	@Consumes(MediaType.APPLICATION_XML)
	public void addUser(User user) throws JAXBException, IOException, Exception {
		getDiaryApp().getUsers().addUser(user);
		getDiaryApp().saveUsers();
	}
}