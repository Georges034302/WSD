package uts.wsd.rest;

import uts.wsd.*;
import javax.ws.rs.*;
import javax.ws.rs.core.*;


@Path("geo")
public class GeoService {

    @Context
    private UriInfo Context;

    public GeoService() {
    }
    
    @Path("location")
    @GET
    @Produces(MediaType.APPLICATION_XML)
    public Location location(@QueryParam("ip")String ip,@QueryParam("countryCode") String countryCode,@QueryParam("countryName") String countryName,@QueryParam("city") String city,@QueryParam("cipCode")String zipCode){
        return new Location(ip,countryCode,countryName,city,zipCode);
    }
    

}
