package uts.wsd.soap;

import java.io.*;
import javax.annotation.*;
import javax.jws.*;
import javax.servlet.*;
import javax.xml.bind.*;
import javax.xml.ws.*;
import javax.xml.ws.handler.*;
import uts.wsd.*;

/**
 * Spring 2018
 * @author George
 */
@WebService(serviceName = "librarySOAP")
public class LibrarySOAP {

    @Resource
    private WebServiceContext context;
   
    private StudentApplication getStudentApp() throws JAXBException, Exception{
         ServletContext application = (ServletContext)context.getMessageContext().get(MessageContext.SERVLET_CONTEXT);
        // The web server can handle requests from different clients in parallel.
        // These are called "threads".
        //
        // We do NOT want other threads to manipulate the application object at the same
        // time that we are manipulating it, otherwise bad things could happen.
        //
        // The "synchronized" keyword is used to lock the application object while
        // we're manpulating it.
        synchronized (application) {
            StudentApplication studentApp = (StudentApplication) application.getAttribute("studentApp");
            if (studentApp == null) {
                studentApp = new StudentApplication();
                studentApp.setFilePath(application.getRealPath("WEB-INF/students.xml"));
                application.setAttribute("studentApp", studentApp);
            }
            return studentApp;
        }
    }
    /**
     * This is a sample web service operation
     * @param txt
     * @return 
     */
    @WebMethod(operationName = "hello")
    public String hello(@WebParam(name = "name") String txt) {
        return "Hello " + txt + " !";
    }
    
    @WebMethod
    public Students displayStudents() throws IOException, Exception{
        return getStudentApp().getStudents();
    }
    
    @WebMethod
    public String getFilePath() throws IOException, Exception{
        return  getStudentApp().getFilePath();
    }
}
