package uts.wsd.soap.client;

import java.io.*;
import javax.xml.parsers.*;
import org.xml.sax.*;
import uts.controller.*;

/**
 * Spring 2018
 * @author George
 */
public class LibraryClient {
    
    public static void main(String[] args) throws ParserConfigurationException, SAXException, IOException_Exception{
       LibrarySOAP_Service locator = new LibrarySOAP_Service();
       LibrarySOAP library = locator.getLibrarySOAPPort();
       
       PrintWriter writer = new PrintWriter(System.out);
       //StudentsPrinter.xml.print(library.getFilePath(), writer);
    }
    
}
