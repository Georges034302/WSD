package uts.wsd.soap.client;

public class MathClient {

    Math_Service locator = new Math_Service();
    Math ms = locator.getMathPort();

    public MathClient() {
    }

    public static void main(String[] args) {
        int n = MathClient.getN();
        new MathClient().calculate(n);
    }
    public static int getN() {
        System.out.print(" N = ");
        return In.nextInt();
    }
    private void show(String action, double result) {
        System.out.println(action + " = " + result);
    }
    private void calculate(int n) {
        show("factorial", ms.factorial(n));
        show("squareroot", ms.squareroot(n));
        show("logarithm", ms.logarithm(n));
        show("exponent", ms.exponent(n));
    }    
}
