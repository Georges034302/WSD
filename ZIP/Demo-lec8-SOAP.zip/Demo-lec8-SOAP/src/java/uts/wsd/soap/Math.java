/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.wsd.soap;

import javax.jws.WebMethod;
import javax.jws.WebParam;
import javax.jws.WebService;
import uts.wsd.*;

@WebService(serviceName = "Math")
public class Math {

    @WebMethod(operationName = "factorial")
    public int getFactorial(@WebParam(name = "n") int n) {
        return new Formula(n).getFactorial();
    }
    
    @WebMethod(operationName="logarithm")
    public double getLogarithm(@WebParam(name = "n") int n){
        return new Formula(n).getLogarithm();
    }
    @WebMethod(operationName="squareroot")
    public double getSquareroot(@WebParam(name = "n") int n){
        return new Formula(n).getSquareroot();
    }
    @WebMethod(operationName="exponent")
    public double getExponent(@WebParam(name = "n") int n){
        return new Formula(n).getExponent();
    }
}
