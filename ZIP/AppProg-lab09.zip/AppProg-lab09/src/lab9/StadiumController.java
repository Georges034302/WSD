package lab9;

import java.net.URL;
import javafx.collections.*;
import javafx.event.*;
import javafx.fxml.*;
import javafx.scene.text.*;
import javafx.scene.control.*;
import javafx.stage.*;
import javafx.beans.property.*;
import java.io.*;

public class StadiumController {
    //#Fields:
    //create a stadium field instance.
    //declare an FXML sellBtn    
    //declare an FXML amountTf    
        
    //define a constant get method to return stadium.   
    //define a constant get method to return amountTf parsed amount.
    //define a constant set that takes an integer amount method to modify amountTf .    
    
    //define an FXML initialize method 
    //- this method load FXML components after an instance is created.
       
    //define an FXML handleSell method that captures ActionEvents
    //-create a group instance using getStadium()
    //-create local integer amount from getAmount()
    //-test if a group can sell an amount
    //-reset amount sold to zero
   
    
}
