package factory;

/**
 * Spring 2018
 * @author George
 */
public interface Vehicle {    
    public void start();
    public void stop();
    public void move(int distance);
}
