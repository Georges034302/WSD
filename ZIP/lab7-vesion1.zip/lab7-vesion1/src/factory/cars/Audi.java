package factory.cars;

import factory.Car;

public class Audi extends Car{
    public Audi(){
        super("Audi",0);
    }
}
