package factory.cars;

import factory.Car;

public class BMW extends Car{
    
    public BMW(){
        super("BMW",0);
    }    
}
