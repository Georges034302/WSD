package factory;

public class Car implements Vehicle{

    protected String type;
    protected int pos;
    
    protected Car(String type, int start){
        this.type = type;
        this.pos = start;
    }
    
    @Override
    public void start() {
        System.out.println(type +" is starting at position: "+pos);
    }

    @Override
    public void stop() {
        System.out.println(type +" is stopping at position: "+pos);
    }

    @Override
    public void move(int distance) {
        pos += distance;
        System.out.println(type +" has moved to position: "+pos);
    }
    
}
