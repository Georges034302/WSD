
import factory.*;
import factory.cars.*;
import java.util.*;

/**
 * Spring 2018
 * @author George
 */
public class Main {
    public static void main(String[] args){ new Main().use();};
    
    private ArrayList<Car> cars = new ArrayList<>();
    
    public Main(){
        cars.add(new BMW());
        cars.add(new Audi());        
    }
    private void start(){
        for(Car car:cars)
            car.start();
    }
    
    private void stop(){
        for(Car car:cars)
            car.stop();
    }
    
    private void move(){
        for(Car car:cars)
            car.move(5);
    }
    
    private char readChoice(){
        System.out.print("Cars (s/p/m/x): ");
        return In.nextChar();
    }
    
    private void use(){
        char c;
        while((c = readChoice()) != 'x'){
            switch(c){
                case 's': start(); break;
                case 'p': stop(); break;
                case 'm': move(); break;
                default: help(); break;
            }
        }
    }
    
    private void help(){
        System.out.println("====================\n"
                + "Cars (s/p/m/x): \n"
                + "s - start \n"
                + "p - stop \n"
                + "m - move \n"
                + "x - exit \n");
    }
}
