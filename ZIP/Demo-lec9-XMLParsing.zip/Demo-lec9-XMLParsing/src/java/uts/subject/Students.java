/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package uts.subject;

import java.io.Serializable;
import javax.xml.bind.annotation.*;
import java.util.ArrayList;

/**
 *
 * @author George
 */
@XmlRootElement(name = "students")
@XmlAccessorType(XmlAccessType.FIELD)
public class Students implements Serializable {

    @XmlElement(name = "student")
    private ArrayList<Student> list = new ArrayList<>();

    public ArrayList<Student> getList() {
        return list;
    }

    public void addStudent(Student student) {
        list.add(student);
    }

    public void removeStudent(Student student) {
        list.remove(student);
    }
    
    public Student getStudent(int ID) {
        for (Student student : list) {
            if (student.getID() == ID) {
                return student;
            }
        }
        return null;
    }

    public Student login(int ID, String password) {
        // For each student in the list...
        for (Student student : list) {
            if (student.getID() == ID && student.getPassword().equals(password)) {
                return student; // Login correct. Return this student.
            }
        }
        return null; // Login incorrect. Return null.
    }
}
